# PanggilSaza Production Deployment Checklist

## Accounts
- [ ] Create Supabase project (database/auth/storage).
- [ ] Create Vercel account and connect private Git repository.
- [ ] Create Midtrans merchant account; complete required business verification.
- [ ] Decide domain purchase later; start with Vercel subdomain.

## Supabase
- [ ] Run `supabase/schema.sql`.
- [ ] Set Auth site URL and redirect URLs to deployed Vercel URL.
- [ ] Configure email provider and password reset.
- [ ] Create first admin securely (manual trusted process; never public role metadata).
- [ ] Test RLS as each of admin, tutor, parent and student.
- [ ] Add explicit guardian-to-child and tutor-to-class relationship policies.
- [ ] Configure backups and retention.

## Product rules to confirm
- [ ] Prices for each combination: class type × 4/8/12 meetings × 60/90 minutes.
- [ ] Group class capacity and minimum enrolment.
- [ ] Expiry period for package balances.
- [ ] Cancellation/no-show/make-up policy.
- [ ] Refund and partial-payment policy.
- [ ] Who may finalize attendance and deduct a meeting.

## Payments
- [ ] Implement server-side Midtrans Snap token creation.
- [ ] Verify webhook signature and fetch status server-to-server.
- [ ] Handle pending, settlement, capture, deny, expire, cancel, refund.
- [ ] Make webhook processing idempotent.
- [ ] Reconcile payments daily; never trust client-side payment success.

## Release gates
- [ ] `npm run build` passes.
- [ ] Login, logout, reset password and session expiry tested.
- [ ] Role escalation tests pass.
- [ ] Cross-student data access tests pass.
- [ ] Payment sandbox tests pass.
- [ ] Attendance and meeting balance concurrency tests pass.
- [ ] Privacy notice, terms, consent and data retention policy published.


## Package pricing and rescheduling
- [ ] Set prices for all 12 package combinations; keep zero-price packages inactive.
- [ ] Define whether package expiry is calendar-based or lesson-count based.
- [ ] Define group class pricing as one class fee; document capacity and minimum enrolment.
- [ ] Build admin price editor with validation and price-change audit history.
- [ ] Build invoice generation for package purchase and partial-payment rules if supported.
- [ ] Build reschedule request form with original class, proposed date/time, reason and requester.
- [ ] Validate tutor availability, room/online slot, student availability, group capacity and time-zone.
- [ ] Require authorized approval; store old/new schedule and reviewer.
- [ ] Ensure rejection/cancellation leaves original class unchanged.
- [ ] Ensure rescheduling never deducts package balance; only finalized attended class deducts once.
- [ ] Test simultaneous reschedule requests and race conditions.
