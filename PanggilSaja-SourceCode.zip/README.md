# PanggilSaza — Production Starter

This is a production-oriented starter scaffold, **not a deployed or fully completed production service**.

## Included
- Next.js App Router application.
- Supabase SSR authentication helpers and login/logout.
- Role-aware server-side dashboard gate (`admin`, `tutor`, `parent`, `student`).
- SQL schema for students, tutors, classes (private/group), packages, enrollments, attendance, invoices, payments, worksheets, assignments and progress reports.
- Package constraints for 4/8/12 meetings and 60/90 minute sessions.
- Initial RLS policies.
- Midtrans webhook signature-verification skeleton.

## Important limitations before real launch
1. Create a Supabase project and run `supabase/schema.sql`.
2. Complete and test all RLS policies, especially parent-child and tutor-class mappings. The starter intentionally avoids granting broad client writes.
3. Add admin-only user provisioning and role assignment through a server-side service-role function. Never allow public signup metadata to choose a privileged role.
4. Implement payment creation with Midtrans Snap on the server, server-to-server transaction status verification, idempotent webhook settlement and DB transaction logic. Current webhook verifies signature but deliberately does not mark an invoice paid.
5. Add full CRUD screens, validation, audit logs, rate limiting, password reset, email verification, MFA for admins, backups and monitoring.
6. Configure package prices and cancellation/expiry rules with the business owner.
7. Run security tests for every role and build tests before production.

## Local setup
- Install Node.js 20+.
- `npm install`
- Copy `.env.example` to `.env.local` and fill Supabase credentials.
- Run SQL in Supabase SQL Editor.
- `npm run dev`

## Deployment
- Push this project to a private Git repository.
- Import repository into Vercel.
- Set environment variables in Vercel (Production and Preview separately).
- Deploy to a Vercel-provided URL, then attach a custom domain later.
- Verify auth callback URLs and Supabase allowed redirect URLs.

## Security rules
- Do not commit `.env.local`.
- Never expose `SUPABASE_SERVICE_ROLE_KEY` or `MIDTRANS_SERVER_KEY` in client-side code.
- Do not trust payment return URLs; trust verified provider notifications only.
- Do not deduct a meeting until attendance is finalized as `present` and the deduction is idempotent.


## Package and reschedule extension
- Package catalogue seeds the 12 combinations (private/group x 4/8/12 meetings x 60/90 minutes) with inactive, zero-price placeholders. Admin must set real prices before activation.
- Added reschedule request and immutable schedule-history tables.
- Added admin package catalogue and reschedule-history read pages.
- These are schema/read foundations, not completed workflows: price editing, package activation, invoice generation, online payment settlement, reschedule request form, conflict detection and atomic approval still require implementation and tests.
