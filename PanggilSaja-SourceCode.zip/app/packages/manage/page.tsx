
import { requireUser } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";

export default async function ManagePackages() {
  const { supabase } = await requireUser(["admin"]);
  const { data: packages } = await supabase.from("learning_packages")
    .select("id,name,class_type,meeting_count,duration_minutes,price_idr,active")
    .order("class_type").order("meeting_count").order("duration_minutes");
  return <main style={{maxWidth:1050,margin:"35px auto",padding:20}}>
    <h1 style={{color:"#1766b2"}}>Pengaturan Harga Paket</h1>
    <p>12 kombinasi paket. Masukkan harga aktual sebelum paket diaktifkan.</p>
    <div className="card" style={{overflowX:"auto"}}>
      <table style={{width:"100%",fontSize:13,borderCollapse:"collapse"}}>
        <thead><tr>{["Paket","Model","Pertemuan","Durasi","Harga (IDR)","Status"].map(x=><th style={{textAlign:"left",padding:10}} key={x}>{x}</th>)}</tr></thead>
        <tbody>{(packages??[]).map(p=><tr key={p.id}>
          <td style={{padding:10}}>{p.name}</td><td>{p.class_type}</td><td>{p.meeting_count}</td><td>{p.duration_minutes} menit</td>
          <td>{p.price_idr.toLocaleString("id-ID")}</td><td>{p.active?"Aktif":"Belum diaktifkan"}</td>
        </tr>)}</tbody>
      </table>
    </div>
    <p style={{color:"#9a5b17",fontSize:12}}>Starter ini menampilkan katalog harga. Form pengubahan harga, riwayat perubahan, validasi harga, dan aktivasi paket masih perlu diimplementasikan sebagai aksi server admin sebelum produksi.</p>
    <a href="/">← Dashboard</a>
  </main>;
}
