import { requireUser } from "@/lib/auth";
export default async function Packages(){
 await requireUser();
 const counts=[4,8,12];
 return <main style={{maxWidth:950,margin:"40px auto",padding:20}}><h1 style={{color:"#1766b2"}}>Paket PanggilSaza</h1><p>Setiap paket tersedia untuk kelas privat maupun kelompok.</p>
 <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(220px,1fr))",gap:16}}>
 {counts.map(n=><section className="card" key={n}><h2>{n} Pertemuan</h2><p>Pilih durasi per sesi:</p><p>60 menit</p><p>90 menit</p><small>Harga ditentukan administrator berdasarkan program dan model kelas.</small></section>)}
 </div><p><a href="/">← Kembali ke dashboard</a></p></main>;
}
