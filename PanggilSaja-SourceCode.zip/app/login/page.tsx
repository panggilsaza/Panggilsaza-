"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function Login() {
  const [email,setEmail]=useState(""); const [password,setPassword]=useState("");
  const [error,setError]=useState(""); const [busy,setBusy]=useState(false);
  async function submit(e:React.FormEvent) {
    e.preventDefault(); setBusy(true); setError("");
    const supabase=createClient();
    const {error}=await supabase.auth.signInWithPassword({email,password});
    if(error){setError("Email atau password tidak valid, atau akun belum aktif.");setBusy(false);return;}
    window.location.assign("/");
  }
  return <main style={{maxWidth:420,margin:"10vh auto",padding:24}}>
    <div className="card"><div style={{fontSize:42}}>🐳 🧒</div><h1 style={{color:"#1766b2"}}>PanggilSaza</h1><p>Masuk ke akun pembelajaran Anda.</p>
      <form onSubmit={submit}><label>Email<input className="input" type="email" value={email} onChange={e=>setEmail(e.target.value)} required autoComplete="username"/></label>
      <label style={{display:"block",marginTop:14}}>Password<input className="input" type="password" value={password} onChange={e=>setPassword(e.target.value)} required autoComplete="current-password"/></label>
      {error&&<p style={{color:"#b33"}}>{error}</p>}<button className="btn" style={{width:"100%",marginTop:18}} disabled={busy}>{busy?"Memproses...":"Login"}</button></form>
      <p style={{fontSize:12,color:"#718096",marginTop:16}}>Akun dibuat dan diaktifkan oleh administrator. Hubungi admin jika Anda belum memiliki akses.</p>
    </div>
  </main>;
}
