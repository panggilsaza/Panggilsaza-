export default function Unauthorized(){return <main style={{padding:40}}><h1>Akses tidak diizinkan</h1><p>Hubungi administrator PanggilSaza.</p></main>}
