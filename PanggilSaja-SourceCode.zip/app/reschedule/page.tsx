import { requireUser } from "@/lib/auth";
import Link from "next/link";
import { submitReschedule, reviewReschedule } from "./actions";

export default async function ReschedulePage() {
 const { supabase, profile } = await requireUser();
 const {data: classes} = await supabase.from("classes").select("id,title,starts_at,duration_minutes,tutor_id,status,class_students(student_id,students(full_name))").eq("status","scheduled").order("starts_at").limit(100);
 const {data: requests} = await supabase.from("reschedule_requests").select("id,class_id,reason,proposed_starts_at,original_starts_at,status,created_at,review_note").order("created_at",{ascending:false}).limit(100);
 const admin=profile.role==="admin";
 return <main style={{maxWidth:1050,margin:"32px auto",padding:20}}>
  <h1 style={{color:"#1766b2"}}>Reschedule Kelas</h1>
  <p>Pengajuan wajib masuk minimal 24 jam sebelum kelas dimulai. Saldo paket tidak dipotong karena reschedule.</p>
  <section className="card"><h2>Ajukan perubahan jadwal</h2>
   <form action={submitReschedule} className="form">
    <label>Kelas<select name="class_id" required defaultValue=""><option value="" disabled>Pilih kelas</option>{(classes??[]).map((c:any)=><option key={c.id} value={c.id}>{c.title} — {new Date(c.starts_at).toLocaleString("id-ID")}</option>)}</select></label>
    <label>Tanggal & waktu baru<input type="datetime-local" name="proposed_starts_at" required /></label>
    <label>Alasan<textarea name="reason" minLength={5} maxLength={1000} required /></label>
    <button type="submit">Kirim pengajuan</button>
   </form>
  </section>
  <section className="card"><h2>Riwayat pengajuan</h2>
   {!requests?.length?<p>Belum ada permintaan reschedule.</p>:requests.map((r:any)=><article key={r.id} className="item">
    <b>{r.class_id.slice(0,8)} · {r.status}</b>
    <p>Jadwal awal: {r.original_starts_at?new Date(r.original_starts_at).toLocaleString("id-ID"):"-"}</p>
    <p>Jadwal diminta: {new Date(r.proposed_starts_at).toLocaleString("id-ID")}</p><p>Alasan: {r.reason}</p>
    {admin&&r.status==="pending"&&<form action={reviewReschedule} className="inline">
      <input type="hidden" name="request_id" value={r.id}/>
      <input name="note" placeholder="Catatan Admin (opsional)"/>
      <button name="decision" value="approve">Setujui</button><button name="decision" value="reject" className="secondary">Tolak</button>
    </form>}
    {r.review_note&&<small>Catatan: {r.review_note}</small>}
   </article>)}
  </section>
  <p className="notice">Pengecekan konflik tutor dilakukan saat persetujuan di database. Pengajuan yang melewati batas 24 jam ditolak. Persetujuan mengubah jadwal dan menyimpan riwayat lama/baru dalam satu transaksi.</p>
  <Link href="/">← Dashboard</Link>
 </main>;
}
