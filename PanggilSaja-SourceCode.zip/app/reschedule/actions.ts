"use server";
import { requireUser } from "@/lib/auth";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

export async function submitReschedule(form: FormData) {
 const {supabase}=await requireUser();
 const classId=String(form.get("class_id")||"");
 const local=String(form.get("proposed_starts_at")||"");
 const reason=String(form.get("reason")||"").trim();
 if(!classId||!local||reason.length<5) redirect("/reschedule?error=invalid");
 const {error}=await supabase.rpc("submit_reschedule",{p_class_id:classId,p_new_start:new Date(local).toISOString(),p_reason:reason});
 if(error) redirect("/reschedule?error="+encodeURIComponent(error.message));
 revalidatePath("/reschedule"); redirect("/reschedule?success=submitted");
}
export async function reviewReschedule(form: FormData) {
 const {supabase,profile}=await requireUser(["admin"]);
 const id=String(form.get("request_id")||"");
 const decision=String(form.get("decision")||"");
 if(!id||!["approve","reject"].includes(decision)) redirect("/reschedule?error=invalid");
 const {error}=await supabase.rpc("review_reschedule",{p_request_id:id,p_approve:decision==="approve",p_note:String(form.get("note")||"")||null});
 if(error) redirect("/reschedule?error="+encodeURIComponent(error.message));
 revalidatePath("/reschedule"); redirect("/reschedule?success=reviewed");
}
