import { requireUser } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import Link from "next/link";

const rupiah = (n:number) => new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(n);

export default async function BillingPage() {
 const { supabase, profile } = await requireUser();
 const admin = profile.role === "admin";
 let q = supabase.from("invoices").select("id,invoice_number,amount_idr,status,payment_method,description,due_at,paid_at,created_at,students(full_name)").order("created_at",{ascending:false}).limit(100);
 const {data: invoices} = await q;
 const {data: ledger} = await supabase.from("billing_ledger").select("id,quantity,note,created_at,students(full_name)").order("created_at",{ascending:false}).limit(50);
 return <main style={{maxWidth:1100,margin:"32px auto",padding:20}}>
  <h1 style={{color:"#1766b2"}}>Billing & Pembayaran</h1>
  <p>Tagihan, status pembayaran, dan mutasi saldo pertemuan.</p>
  <section className="card"><h2>Daftar invoice</h2>
   {!invoices?.length?<p>Belum ada invoice.</p>:<div style={{overflowX:"auto"}}><table style={{width:"100%",fontSize:13}}>
    <thead><tr><th>Invoice</th><th>Siswa</th><th>Jumlah</th><th>Metode</th><th>Status</th><th>Jatuh tempo</th></tr></thead>
    <tbody>{invoices.map((x:any)=><tr key={x.id}><td>{x.invoice_number??x.id.slice(0,8)}</td><td>{x.students?.full_name??"-"}</td><td>{rupiah(x.amount_idr)}</td><td>{x.payment_method??"-"}</td><td>{x.status}</td><td>{x.due_at?new Date(x.due_at).toLocaleDateString("id-ID"):"-"}</td></tr>)}</tbody>
   </table></div>}
  </section>
  <section className="card"><h2>Mutasi saldo pertemuan</h2>
   {!ledger?.length?<p>Belum ada transaksi saldo.</p>:<ul>{ledger.map((x:any)=><li key={x.id}>{x.students?.full_name??"Siswa"} — {x.quantity} pertemuan — {x.note} ({new Date(x.created_at).toLocaleString("id-ID")})</li>)}</ul>}
  </section>
  {admin&&<p className="notice">Admin: invoice dibuat dan pembayaran manual dikonfirmasi melalui fungsi server-side yang tersedia pada migration SQL. Form administrasi dan integrasi Midtrans live masih memerlukan konfigurasi serta pengujian kredensial.</p>}
  <Link href="/">← Dashboard</Link>
 </main>;
}
