import { NextResponse } from "next/server";
import crypto from "node:crypto";

/**
 * Midtrans notification endpoint.
 * Verify signature_key before changing invoice/payment state.
 * Never trust a browser redirect as proof of payment.
 */
export async function POST(request: Request) {
  const body = await request.json();
  const serverKey = process.env.MIDTRANS_SERVER_KEY;
  if (!serverKey) return NextResponse.json({error:"Payment provider is not configured"}, {status:503});
  const expected = crypto.createHash("sha512")
    .update(`${body.order_id}${body.status_code}${body.gross_amount}${serverKey}`)
    .digest("hex");
  if (typeof body.signature_key !== "string" ||
      !crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(body.signature_key))) {
    return NextResponse.json({error:"Invalid signature"}, {status:401});
  }
  // TODO production: fetch transaction status from Midtrans API server-to-server,
  // then update invoice + payment using a service-role client in a DB transaction.
  // Handle settlement/capture, pending, deny, expire, cancel and refund idempotently.
  return NextResponse.json({received:true, order_id:body.order_id, note:"Signature verified; DB settlement handler must be completed."});
}
