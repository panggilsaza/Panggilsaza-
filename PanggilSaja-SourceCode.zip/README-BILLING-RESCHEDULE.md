# Panggil Saja — Billing & Reschedule increment

## Kebijakan yang ditetapkan
- Masa berlaku paket: Admin mengatur `validity_days` pada katalog paket. Nilai tersebut disalin ke masa berlaku enrollment saat paket diaktifkan/dibuat.
- Reschedule: permintaan hanya diterima jika kelas lama dan waktu baru berjarak minimal 24 jam dari waktu pengajuan.
- No-show tanpa pemberitahuan: status final `absent_unnotified` mengurangi satu pertemuan.
- `present` mengurangi satu pertemuan; `permission`, `cancelled`, dan reschedule tidak mengurangi saldo.
- Pemotongan saldo idempotent melalui `attendance.balance_deducted_at`, unique ledger attendance, dan row lock.

## Yang ditambahkan
- SQL migration untuk masa berlaku, invoice metadata, payment metadata, billing ledger, RPC reschedule, approval, finalisasi kehadiran, invoice, dan konfirmasi pembayaran manual.
- Halaman billing untuk invoice dan mutasi saldo.
- Form permintaan reschedule serta tombol approval/rejection Admin.
- Pemeriksaan bentrok jadwal tutor ketika Admin menyetujui reschedule.
- Riwayat jadwal lama/baru yang ditulis dalam transaksi persetujuan.

## Cara menerapkan
1. Buat backup database Supabase.
2. Jalankan `supabase/migrations/20261107_billing_reschedule_production.sql` setelah schema awal.
3. Set `validity_days` tiap paket di `learning_packages`; nilai awal 30 hari adalah default teknis dan harus ditinjau Admin.
4. Pastikan setiap peserta kelas memiliki `class_students.enrollment_id` yang menunjuk enrollment aktif.
5. Uji skenario present, absent_unnotified, permission, cancelled, pengajuan reschedule di bawah/di atas 24 jam, bentrok tutor, approval/rejection, dan percobaan double-submit.
6. Audit RLS, function owner/grants, dan akses data per role di staging sebelum produksi.

## Batasan yang masih terbuka (belum boleh dianggap live)
- Form administrasi untuk mengubah `validity_days`, membuat invoice, dan merekam konfirmasi manual belum tersedia sebagai UI; fungsi database sudah disediakan.
- Integrasi Midtrans belum menyelesaikan verifikasi status server-to-server dan settlement idempotent.
- Belum ada notifikasi email/WhatsApp, pembayaran online live, refund, pajak, atau rekonsiliasi bank.
- Konflik jadwal saat ini memeriksa bentrok tutor; konflik kapasitas/ruang dan seluruh anggota kelas kelompok perlu aturan tambahan.
- RLS dan privilege untuk operasi RPC wajib diuji secara menyeluruh; jangan gunakan pada data produksi sebelum security review.
- Build belum dijalankan dalam lingkungan dengan dependency terpasang. Tidak ada klaim bahwa aplikasi sudah terkompilasi atau ter-deploy.

## Environment
Salin `.env.example` menjadi `.env.local`, isi kredensial Supabase. Jangan pernah memasukkan service-role key ke browser.
