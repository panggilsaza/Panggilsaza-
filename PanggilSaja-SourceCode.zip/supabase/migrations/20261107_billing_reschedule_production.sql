-- Panggil Saja: billing + reschedule production rules.
-- Apply AFTER supabase/schema.sql. Review all RLS/security in staging before production.
alter table public.learning_packages
  add column if not exists validity_days integer not null default 30
  check (validity_days between 1 and 730);
alter table public.enrollments
  add column if not exists purchased_at timestamptz not null default now(),
  add column if not exists expired_at timestamptz;
alter table public.invoices
  add column if not exists invoice_number text unique,
  add column if not exists payment_method text check (payment_method in ('manual','midtrans')),
  add column if not exists description text,
  add column if not exists paid_at timestamptz;
alter table public.payments
  add column if not exists idempotency_key text unique,
  add column if not exists confirmed_by uuid references public.profiles(id);
alter table public.reschedule_requests
  add column if not exists original_starts_at timestamptz,
  add column if not exists policy_deadline_at timestamptz;

create table if not exists public.billing_ledger (
 id uuid primary key default gen_random_uuid(),
 enrollment_id uuid not null references public.enrollments(id),
 student_id uuid not null references public.students(id),
 class_id uuid not null references public.classes(id),
 attendance_id uuid not null unique references public.attendance(id),
 entry_type text not null check(entry_type in ('lesson_debit','lesson_credit','adjustment')),
 quantity integer not null check(quantity <> 0),
 note text not null,
 created_by uuid references public.profiles(id),
 created_at timestamptz not null default now()
);
alter table public.billing_ledger enable row level security;
create policy "admin_all_billing_ledger" on public.billing_ledger
 for all using(public.is_admin()) with check(public.is_admin());
create policy "student_read_billing_ledger" on public.billing_ledger for select using (
 exists(select 1 from public.students s where s.id=student_id and
 (s.profile_id=auth.uid() or s.parent_profile_id=auth.uid()))
);

-- Admin-controlled expiry is snapshotted into enrollment at purchase time.
create or replace function public.create_enrollment_for_invoice(
 p_student_id uuid, p_package_id uuid, p_invoice_id uuid
) returns uuid language plpgsql security definer set search_path=public as $$
declare pkg public.learning_packages%rowtype; inv public.invoices%rowtype; new_id uuid;
begin
 if not public.is_admin() then raise exception 'admin_only'; end if;
 select * into pkg from public.learning_packages where id=p_package_id and active=true for share;
 if not found or pkg.price_idr <= 0 then raise exception 'package_not_sellable'; end if;
 select * into inv from public.invoices where id=p_invoice_id and student_id=p_student_id and status='paid';
 if not found then raise exception 'invoice_not_paid'; end if;
 insert into public.enrollments(student_id,package_id,total_meetings,remaining_meetings,starts_on,expires_on,expired_at,status)
 values(p_student_id,p_package_id,pkg.meeting_count,pkg.meeting_count,current_date,
        current_date + pkg.validity_days, now() + make_interval(days=>pkg.validity_days),'active')
 returning id into new_id;
 update public.invoices set enrollment_id=new_id where id=p_invoice_id;
 return new_id;
end $$;

-- Atomic class reschedule request; strict 24-hour advance notice.
create or replace function public.submit_reschedule(
 p_class_id uuid, p_new_start timestamptz, p_reason text
) returns uuid language plpgsql security definer set search_path=public as $$
declare c public.classes%rowtype; new_id uuid; student_ok boolean;
begin
 if auth.uid() is null then raise exception 'authentication_required'; end if;
 if char_length(trim(coalesce(p_reason,''))) < 5 then raise exception 'reason_too_short'; end if;
 select * into c from public.classes where id=p_class_id for update;
 if not found or c.status <> 'scheduled' then raise exception 'class_not_reschedulable'; end if;
 if c.starts_at <= now() + interval '24 hours' then raise exception 'reschedule_deadline_passed'; end if;
 if p_new_start <= now() + interval '24 hours' then raise exception 'new_time_must_be_24h_ahead'; end if;
 select exists(select 1 from public.class_students cs join public.students s on s.id=cs.student_id
   where cs.class_id=p_class_id and (s.profile_id=auth.uid() or s.parent_profile_id=auth.uid()))
 into student_ok;
 if not public.is_admin() and not student_ok then
   if not exists(select 1 from public.tutors t where t.id=c.tutor_id and t.profile_id=auth.uid()) then
     raise exception 'not_allowed';
   end if;
 end if;
 if exists(select 1 from public.reschedule_requests where class_id=p_class_id and status='pending') then
   raise exception 'pending_request_exists';
 end if;
 insert into public.reschedule_requests(class_id,requested_by,reason,proposed_starts_at,original_starts_at,policy_deadline_at)
 values(p_class_id,auth.uid(),trim(p_reason),p_new_start,c.starts_at,c.starts_at-interval '24 hours')
 returning id into new_id;
 return new_id;
end $$;

-- Admin approval: lock rows, validate tutor overlap, update schedule + immutable history atomically.
create or replace function public.review_reschedule(
 p_request_id uuid, p_approve boolean, p_note text default null
) returns void language plpgsql security definer set search_path=public as $$
declare r public.reschedule_requests%rowtype; c public.classes%rowtype;
begin
 if not public.is_admin() then raise exception 'admin_only'; end if;
 select * into r from public.reschedule_requests where id=p_request_id for update;
 if not found or r.status <> 'pending' then raise exception 'request_not_pending'; end if;
 select * into c from public.classes where id=r.class_id for update;
 if p_approve then
   if c.starts_at <= now() + interval '24 hours' then raise exception 'original_slot_inside_notice_window'; end if;
   if c.tutor_id is not null and exists(
     select 1 from public.classes x where x.id<>c.id and x.tutor_id=c.tutor_id
       and x.status='scheduled'
       and tstzrange(x.starts_at,x.starts_at+make_interval(mins=>x.duration_minutes),'[)')
         && tstzrange(r.proposed_starts_at,r.proposed_starts_at+make_interval(mins=>c.duration_minutes),'[)')
   ) then raise exception 'tutor_schedule_conflict'; end if;
   insert into public.reschedule_history(request_id,class_id,old_starts_at,new_starts_at,changed_by,reason)
   values(r.id,c.id,c.starts_at,r.proposed_starts_at,auth.uid(),r.reason);
   update public.classes set starts_at=r.proposed_starts_at where id=c.id;
   update public.reschedule_requests set status='approved',reviewed_by=auth.uid(),reviewed_at=now(),
     review_note=p_note,updated_at=now() where id=r.id;
 else
   update public.reschedule_requests set status='rejected',reviewed_by=auth.uid(),reviewed_at=now(),
     review_note=p_note,updated_at=now() where id=r.id;
 end if;
end $$;

-- Attendance finalization is idempotent. Present OR unannounced absent consumes exactly one lesson.
-- Permission/cancelled do not deduct. Admin records no-show as absent_unnotified.
alter table public.attendance
  add column if not exists absence_notified boolean not null default true,
  add column if not exists finalized_at timestamptz;
do $$ begin
 if not exists(select 1 from pg_type where typname='attendance_status_v2') then
   create type public.attendance_status_v2 as enum ('scheduled','present','absent','permission','cancelled','make_up','absent_unnotified');
 end if;
end $$;
alter table public.attendance alter column status drop default;
alter table public.attendance alter column status type public.attendance_status_v2
 using (case when status::text='absent' and absence_notified=false then 'absent_unnotified'
             else status::text end)::public.attendance_status_v2;
alter table public.attendance alter column status set default 'scheduled';

create or replace function public.finalize_attendance(p_attendance_id uuid, p_status text, p_absence_notified boolean default true)
returns void language plpgsql security definer set search_path=public as $$
declare a public.attendance%rowtype; cs public.class_students%rowtype; e public.enrollments%rowtype;
begin
 if not (public.is_admin() or exists(
   select 1 from public.attendance aa join public.classes c on c.id=aa.class_id
   join public.tutors t on t.id=c.tutor_id where aa.id=p_attendance_id and t.profile_id=auth.uid()
 )) then raise exception 'not_allowed'; end if;
 if p_status not in ('present','absent','permission','cancelled','absent_unnotified') then
   raise exception 'invalid_final_status';
 end if;
 if p_status='absent_unnotified' and p_absence_notified then raise exception 'absence_was_notified'; end if;
 select * into a from public.attendance where id=p_attendance_id for update;
 if not found then raise exception 'attendance_not_found'; end if;
 if a.balance_deducted_at is not null then raise exception 'attendance_already_finalized'; end if;
 update public.attendance set status=p_status::public.attendance_status_v2,
   absence_notified=p_absence_notified, finalized_at=now(), marked_by=auth.uid(), marked_at=now()
 where id=a.id;
 if p_status in ('present','absent_unnotified') then
   select * into cs from public.class_students where class_id=a.class_id and student_id=a.student_id;
   if cs.enrollment_id is null then raise exception 'student_has_no_enrollment_for_class'; end if;
   select * into e from public.enrollments where id=cs.enrollment_id for update;
   if not found or e.status<>'active' or e.remaining_meetings<1 then raise exception 'no_active_package_balance'; end if;
   if e.expires_on is not null and e.expires_on < current_date then raise exception 'package_expired'; end if;
   update public.enrollments set remaining_meetings=remaining_meetings-1,
     status=case when remaining_meetings-1=0 then 'depleted' else status end where id=e.id;
   insert into public.billing_ledger(enrollment_id,student_id,class_id,attendance_id,entry_type,quantity,note,created_by)
   values(e.id,a.student_id,a.class_id,a.id,'lesson_debit',-1,
     case when p_status='present' then 'Kelas selesai' else 'Tidak hadir tanpa pemberitahuan' end,auth.uid());
   update public.attendance set balance_deducted_at=now() where id=a.id;
 end if;
end $$;

-- Invoice creation / manual payment confirmation.
create or replace function public.create_invoice(
 p_student_id uuid,p_amount bigint,p_description text,p_method text,p_due_at timestamptz default null
) returns uuid language plpgsql security definer set search_path=public as $$
declare new_id uuid; inv_no text;
begin
 if not public.is_admin() then raise exception 'admin_only'; end if;
 if p_amount<=0 or p_method not in ('manual','midtrans') then raise exception 'invalid_invoice'; end if;
 inv_no := 'PS-'||to_char(now(),'YYYYMMDD')||'-'||upper(substr(replace(gen_random_uuid()::text,'-',''),1,8));
 insert into public.invoices(student_id,amount_idr,status,due_at,invoice_number,payment_method,description)
 values(p_student_id,p_amount,'pending',p_due_at,inv_no,p_method,p_description)
 returning id into new_id;
 return new_id;
end $$;

create or replace function public.confirm_manual_payment(p_invoice_id uuid,p_reference text default null)
returns void language plpgsql security definer set search_path=public as $$
declare i public.invoices%rowtype;
begin
 if not public.is_admin() then raise exception 'admin_only'; end if;
 select * into i from public.invoices where id=p_invoice_id for update;
 if not found or i.status<>'pending' or i.payment_method<>'manual' then raise exception 'invoice_not_payable'; end if;
 insert into public.payments(invoice_id,provider,provider_reference,amount_idr,status,paid_at,confirmed_by)
 values(i.id,'manual',coalesce(p_reference,'MANUAL-'||i.invoice_number),i.amount_idr,'paid',now(),auth.uid());
 update public.invoices set status='paid',paid_at=now() where id=i.id;
end $$;

revoke all on function public.submit_reschedule(uuid,timestamptz,text) from public;
grant execute on function public.submit_reschedule(uuid,timestamptz,text) to authenticated;
revoke all on function public.review_reschedule(uuid,boolean,text) from public;
grant execute on function public.review_reschedule(uuid,boolean,text) to authenticated;
revoke all on function public.finalize_attendance(uuid,text,boolean) from public;
grant execute on function public.finalize_attendance(uuid,text,boolean) to authenticated;
revoke all on function public.create_invoice(uuid,bigint,text,text,timestamptz) from public;
grant execute on function public.create_invoice(uuid,bigint,text,text,timestamptz) to authenticated;
revoke all on function public.confirm_manual_payment(uuid,text) from public;
grant execute on function public.confirm_manual_payment(uuid,text) to authenticated;
revoke all on function public.create_enrollment_for_invoice(uuid,uuid,uuid) from public;
grant execute on function public.create_enrollment_for_invoice(uuid,uuid,uuid) to authenticated;

-- NOTE: Supabase Postgres RPCs execute with function owner privileges. Test auth.uid(),
-- grants, ownership, RLS and role boundaries in a staging project before enabling real payments.
