import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";

export type Role = "admin" | "tutor" | "parent" | "student";

export async function requireUser(allowed?: Role[]) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  const { data: profile } = await supabase
    .from("profiles").select("id, full_name, role, is_active").eq("id", user.id).single();
  if (!profile || !profile.is_active) redirect("/login?error=inactive");
  if (allowed && !allowed.includes(profile.role as Role)) redirect("/unauthorized");
  return { supabase, user, profile };
}
